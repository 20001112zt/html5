/**
 * ==========
 *日记页状态数据
 * ==========
 */
const user = {
	namespaced: true,
	state: {
		userInfo: {
			nickName: '小黄吖',
			motto: '虽然你我会下落不明，你知道我曾为你动过情',
			gender: '0',
			avatarUrl: 'https://6d61-matchbox-79a395-1302390714.tcb.qcloud.la/matchbox/avatar.png'
		}
	},
	mutations: {

	},
	actions: {

	}
}

export default user
